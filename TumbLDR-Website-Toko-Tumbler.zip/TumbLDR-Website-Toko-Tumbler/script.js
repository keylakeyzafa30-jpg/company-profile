// TumbLDR - interaksi menu, pesanan, dan formulir kontak

// GANTI nomor ini dengan nomor WhatsApp milikmu.
// Gunakan kode negara 62, tanpa tanda +, spasi, atau angka 0 di depan.
// Contoh format: 6281234567890
const WHATSAPP_NUMBER = "628xxxxxxxxxx";

// GANTI dengan email TumbLDR yang benar.
const CONTACT_EMAIL = "emailkamu@example.com";

// Menu navigasi untuk tampilan HP
const menuButton = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

if (menuButton && navLinks) {
  menuButton.addEventListener("click", () => {
    const isOpen = navLinks.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(isOpen));
    menuButton.textContent = isOpen ? "×" : "☰";
  });
}

// Tombol pesan produk akan membuka WhatsApp setelah nomor diganti.
document.querySelectorAll(".order-button").forEach((button) => {
  button.addEventListener("click", () => {
    const product = button.dataset.product;
    const price = Number(button.dataset.price).toLocaleString("id-ID");
    if (WHATSAPP_NUMBER.includes("x")) {
      alert("Silakan isi nomor WhatsApp TumbLDR terlebih dahulu di file script.js.");
      return;
    }
    const message = `Halo TumbLDR, saya ingin memesan ${product} dengan harga Rp${price}. Apakah masih tersedia?`;
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank");
  });
});

// Form kontak: menyiapkan email melalui aplikasi email pengguna.
const contactForm = document.querySelector("#contactForm");
if (contactForm) {
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    if (CONTACT_EMAIL === "emailkamu@example.com") {
      alert("Ganti alamat email TumbLDR terlebih dahulu pada bagian CONTACT_EMAIL di file script.js.");
      return;
    }
    const formData = new FormData(contactForm);
    const name = formData.get("name");
    const email = formData.get("email");
    const message = formData.get("message");
    const subject = encodeURIComponent(`Pesan website TumbLDR dari ${name}`);
    const body = encodeURIComponent(`Nama: ${name}\nEmail: ${email}\n\nPesan:\n${message}`);
    window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
  });
}
