// Menu navigasi mobile
document.querySelectorAll(".menu-toggle").forEach((toggle) => {
  const nav = toggle.parentElement.querySelector(".nav-links");
  if (!nav) return;

  toggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", String(isOpen));
    toggle.setAttribute("aria-label", isOpen ? "Tutup navigasi" : "Buka navigasi");
    toggle.textContent = isOpen ? "✕" : "☰";
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Buka navigasi");
      toggle.textContent = "☰";
    });
  });
});

// Tahun footer otomatis
document.querySelectorAll("[data-year]").forEach((el) => {
  el.textContent = new Date().getFullYear();
});

// Isi pilihan layanan jika pengunjung datang dari kartu Produk
const serviceSelect = document.querySelector("#layanan");
if (serviceSelect) {
  const params = new URLSearchParams(window.location.search);
  const requested = params.get("layanan") || "";
  const option = Array.from(serviceSelect.options).find((item) =>
    item.text.toLowerCase().includes(requested.toLowerCase())
  );
  if (option && requested) serviceSelect.value = option.value || option.text;
}

// Formulir demo: validasi lalu siapkan ringkasan pesan.
// Untuk pengiriman sungguhan, sambungkan ke backend atau layanan form.
const contactForm = document.querySelector("#contact-form");
if (contactForm) {
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!contactForm.reportValidity()) return;

    const formData = new FormData(contactForm);
    const summary = [
      "Terima kasih, " + formData.get("nama") + "!",
      "Formulir berhasil diperiksa.",
      "Layanan: " + formData.get("layanan") + ".",
      "Ini masih demo; pesan belum dikirim ke email atau server."
    ].join(" ");

    const status = document.querySelector("#form-status");
    if (status) status.textContent = summary;
  });
}
